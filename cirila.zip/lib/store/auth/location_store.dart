import 'package:cirilla/models/location/user_location.dart';
import 'package:cirilla/service/helpers/request_helper.dart';
import 'package:mobx/mobx.dart';

import 'auth_store.dart';

part 'location_store.g.dart';

class LocationStore = _LocationStore with _$LocationStore;

abstract class _LocationStore with Store {
  // Request helper instance
  late RequestHelper _requestHelper;
  late AuthStore _auth;

  // constructor:-------------------------------------------------------------------------------------------------------
  _LocationStore(RequestHelper requestHelper, AuthStore auth) {
    _requestHelper = requestHelper;
    _auth = auth;
  }

  // store variables:-----------------------------------------------------------
  @observable
  UserLocation _location = UserLocation(lat: 0, lng: 0, address: '', tag: '');

  @observable
  List<UserLocation>? _saved;

  @computed
  UserLocation? get location => _location;

  // actions:-------------------------------------------------------------------
  @action
  Future<void> setLocation({
    required double lat,
    required double lng,
    required String address,
    required String tag,
  }) async {
    _location = UserLocation(lat: lat, lng: lng, address: address, tag: tag);
  }
}
