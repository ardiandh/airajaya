typedef OnChangedBlogType = void Function({Map? sort, String? search});
