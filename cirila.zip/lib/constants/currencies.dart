///
/// Width Multi Currency for WooCommerce – The best free currency exchange plugin – Run smoothly on WooCommerce 5.x
/// https://wordpress.org/plugins/woo-multi-currency/
/// const String CURRENCY_PARAM = 'wmc-currency';
///
///
/// WooCommerce Multilingual – run WooCommerce with WPML
/// https://wordpress.org/plugins/woocommerce-multilingual/
/// const String CURRENCY_PARAM = 'currency';
///

const String CURRENCY_PARAM = 'currency';
