const String URL = 'https://ardiandh.my.id/';

const String CONSUMER_KEY = 'ck_8337b03c4c6aa8022c4082c7d6fce9a71f6c439c';

const String CONSUMER_SECRET = 'cs_c7beb7bdf277f78a8f078ce87b4a8be861a5db06';

const String REST_PREFIX = 'wp-json';

const String defaultLanguage = 'en';

const List<String> languageSupport = ['en', 'ar', 'tr'];

const String googleClientId = '1:1078694094549:android:ce98d8d81cac576fd4e45c';
