dynamic parse(dynamic data) {
  return data;
}

class Element {}
