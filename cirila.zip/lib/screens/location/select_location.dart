import 'package:cirilla/constants/constants.dart';
import 'package:cirilla/mixins/mixins.dart';
import 'package:cirilla/store/store.dart';
import 'package:cirilla/types/types.dart';
import 'package:cirilla/utils/utils.dart';
import 'package:feather_icons/feather_icons.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../screens.dart';
import 'search_location.dart';
import 'widgets/item_location.dart';

class SelectLocationScreen extends StatefulWidget {
  static const routeName = '/location/select_location';

  final SettingStore? store;

  SelectLocationScreen({
    Key? key,
    this.store,
  }) : super(key: key);

  @override
  _SelectLocationScreenState createState() => _SelectLocationScreenState();
}

class _SelectLocationScreenState extends State<SelectLocationScreen> with AppBarMixin {
  double top = 0.47;
  void onPressed(BuildContext context) async {
    TranslateType translate = AppLocalizations.of(context)!.translate;
    await showSearch(
      context: context,
      delegate: SearchLocationScreen(context, translate),
    );
  }

  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);
    MediaQueryData mediaQuery = MediaQuery.of(context);

    double screenHeight = mediaQuery.size.height - 90;

    Widget mapView = GoogleMap(
      mapType: MapType.normal,
      initialCameraPosition: CameraPosition(
        target: LatLng(initlat, initlng),
        zoom: initZoom,
      ),
      myLocationButtonEnabled: false,
    );

    return Scaffold(
      extendBody: true,
      appBar: baseStyleAppBar(
        context,
        title: 'Select Location',
        actions: [
          InkResponse(
            onTap: () => onPressed(context),
            radius: 29,
            child: Icon(
              FeatherIcons.search,
              size: 20,
            ),
          ),
          SizedBox(width: 20),
        ],
      ),
      body: Stack(
        children: [
          mapView,
          NotificationListener<DraggableScrollableNotification>(
            onNotification: (notification) {
              setState(() {
                top = 1 - notification.extent;
              });
              return true;
            },
            child: DraggableScrollableActuator(
              child: DraggableScrollableSheet(
                expand: true,
                initialChildSize: 0.53,
                minChildSize: 0.3,
                maxChildSize: 0.85,
                builder: (
                  BuildContext context,
                  ScrollController scrollController,
                ) {
                  return Container(
                    color: theme.scaffoldBackgroundColor,
                    child: SingleChildScrollView(
                      controller: scrollController,
                      padding: EdgeInsets.symmetric(horizontal: layoutPadding),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ItemLocation(primaryIcon: true),
                          SizedBox(height: 16),
                          Text('Nearby Places', style: theme.textTheme.subtitle1),
                          SizedBox(height: 8),
                          ItemLocation(),
                          ItemLocation(),
                          ItemLocation(),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          Positioned(
            top: screenHeight * top - 60,
            right: 20.0,
            child: GestureDetector(
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  shape: BoxShape.circle,
                  boxShadow: initBoxShadow,
                ),
                alignment: Alignment.center,
                child: Icon(Icons.my_location, color: theme.textTheme.subtitle1!.color),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
