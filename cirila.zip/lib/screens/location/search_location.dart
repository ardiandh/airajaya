import 'package:cirilla/constants/constants.dart';
import 'package:cirilla/screens/location/place_service.dart';
import 'package:cirilla/types/types.dart';
import 'package:cirilla/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:ui/notification/notification_screen.dart';
import 'widgets/item_location.dart';

class SearchLocationScreen extends SearchDelegate<Suggestion?> {
  final apiClient = PlaceApiProvider();
  SearchLocationScreen(
    BuildContext context,
    TranslateType translate, {
    Key? key,
    apiClient,
  }) : super(
          searchFieldLabel: translate('address_search'),
          searchFieldStyle: Theme.of(context).textTheme.bodyText2,
        );

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        tooltip: 'Clear',
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
          Navigator.pop(context);
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      tooltip: 'Back',
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return buildSuggestions(context);
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    ThemeData theme = Theme.of(context);
    TranslateType translate = AppLocalizations.of(context)!.translate;
    return FutureBuilder<List<Suggestion>>(
      future: query == "" ? null : apiClient.fetchSuggestions(query, 'vi'),
      builder: (context, snapshot) {
        if (query.trim() == '') {
          return Center(
            child: NotificationScreen(
              title: Text(translate('search_location')!, style: theme.textTheme.headline6),
              content: Text(translate('search_enter_your_address')!, style: theme.textTheme.bodyText2),
              iconData: FontAwesomeIcons.mapMarked,
              isButton: false,
            ),
          );
        }
        if (snapshot.hasData) {
          List<Suggestion> data = snapshot.data!;
          if (snapshot.data!.isEmpty) {
            return Center(
              child: NotificationScreen(
                title: Text(translate('search_location')!, style: theme.textTheme.headline6),
                content: Text(translate('search_enter_your_address')!, style: theme.textTheme.bodyText2),
                iconData: FontAwesomeIcons.mapMarked,
                isButton: false,
              ),
            );
          }
          return ListView.builder(
            itemBuilder: (context, index) {
              Suggestion item = data[index];
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: layoutPadding),
                child: ItemLocation(
                  title: item.mainText,
                  subTitle: item.description,
                  search: query,
                  onTap: () {
                    close(context, snapshot.data![index]);
                  },
                ),
              );
            },
            itemCount: data.length,
          );
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }
}
