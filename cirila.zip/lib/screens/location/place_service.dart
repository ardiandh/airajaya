import 'dart:convert';
import 'package:http/http.dart';
import 'package:cirilla/mixins/utility_mixin.dart' as Mixin;

class Suggestion {
  final String placeId;
  final String description;
  final List terms;
  final String mainText;

  Suggestion(this.placeId, this.description, this.terms, this.mainText);

  @override
  String toString() {
    return 'Suggestion(description: $description, placeId: $placeId)';
  }
}

class PlaceApiProvider {
  final client = Client();

  PlaceApiProvider();

  final apiKey = 'AIzaSyBPTPR_Qi3IZckjADU8z0musXdeeKR1X3I';

  Future<List<Suggestion>> fetchSuggestions(String input, String lang) async {
    final request = Uri.parse(
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?types=address&key=$apiKey&input=$input&language=$lang&components=country:vn');

    final response = await client.get(request);
    if (response.statusCode == 200) {
      final result = json.decode(response.body);
      if (result['status'] == 'OK') {
        // compose suggestions in a list

        return result['predictions'].map<Suggestion>((p) {
          String placeId = Mixin.get(p, ['place_id'], '');
          String description = Mixin.get(p, ['description'], '');
          List terms = Mixin.get(p, ['terms'], []);
          String mainText = Mixin.get(p, ['structured_formatting', 'main_text'], '');
          return Suggestion(placeId, description, terms, mainText);
        }).toList();
      }
      if (result['status'] == 'ZERO_RESULTS') {
        return [];
      }
      throw Exception(result['error_message']);
    } else {
      throw Exception('Failed to fetch suggestion');
    }
  }
}
