import 'package:cirilla/constants/constants.dart';
import 'package:cirilla/mixins/mixins.dart';
import 'package:cirilla/screens/screens.dart';
import 'package:cirilla/store/store.dart';
import 'package:cirilla/types/types.dart';
import 'package:cirilla/utils/app_localization.dart';
import 'package:cirilla/widgets/widgets.dart';
import 'package:feather_icons/feather_icons.dart';
import 'package:flutter/material.dart';
import 'package:ui/ui.dart';

import 'search_location.dart';
import 'widgets/item_address.dart';

class LocationScreen extends StatelessWidget with AppBarMixin {
  static const routeName = '/location';

  final SettingStore? store;

  LocationScreen({
    Key? key,
    this.store,
  }) : super(key: key);
  void onPressed(BuildContext context) async {
    TranslateType translate = AppLocalizations.of(context)!.translate;
    await showSearch(
      context: context,
      delegate: SearchLocationScreen(context, translate),
    );
  }

  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: baseStyleAppBar(
        context,
        title: 'Location',
        actions: [
          InkResponse(
            onTap: () => onPressed(context),
            radius: 29,
            child: Icon(
              FeatherIcons.search,
              size: 20,
            ),
          ),
          SizedBox(width: 20),
        ],
      ),
      bottomNavigationBar: Container(
        // padding: EdgeInsets.symmetric(vertical: 8),
        padding: EdgeInsets.symmetric(vertical: itemPaddingLarge, horizontal: layoutPadding),
        decoration: BoxDecoration(color: theme.canvasColor, boxShadow: initBoxShadow),
        child: SizedBox(
          height: 48,
          child: ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, FormAddressScreen.routeName),
            child: Text('New Address'),
            style: ElevatedButton.styleFrom(
              textStyle: theme.textTheme.subtitle2,
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: layoutPadding),
              child: CirillaTile(
                title: Text(
                  'Auto locate',
                  style: theme.textTheme.caption?.copyWith(color: theme.textTheme.subtitle1!.color),
                ),
                trailing: Icon(
                  Icons.my_location,
                  size: 20,
                  color: theme.textTheme.subtitle1!.color,
                ),
                isChevron: false,
                height: 50,
                onTap: () => Navigator.pushNamed(context, SelectLocationScreen.routeName),
              ),
            ),
            ItemAddress(
              padding: EdgeInsets.symmetric(vertical: itemPaddingLarge, horizontal: layoutPadding),
              isSelect: true,
              addressBasic: true,
              onTap: () {},
            ),
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: itemPaddingMedium, horizontal: layoutPadding),
              color: theme.colorScheme.surface,
              child: Text(
                'Saved',
                style: theme.textTheme.caption!.copyWith(color: theme.textTheme.subtitle1!.color),
              ),
            ),
            Column(
              children: List.generate(3, (index) {
                return DismissibleItem(
                  item: index,
                  onDismissed: (direction) => print('click'),
                  confirmDismiss: (DismissDirection direction) => Future.value(true),
                  child: Column(
                    children: [
                      ItemAddress(
                        padding: EdgeInsets.symmetric(vertical: itemPaddingLarge, horizontal: layoutPadding),
                        onTap: () {},
                      ),
                      Divider(height: 1, thickness: 1, endIndent: layoutPadding, indent: layoutPadding),
                    ],
                  ),
                );
              }),
            )
          ],
        ),
      ),
    );
  }
}
