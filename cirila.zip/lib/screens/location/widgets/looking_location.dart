import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LookingLocationScreen extends StatelessWidget {
  final String? locationTitle;
  final Icon? icon;

  LookingLocationScreen({
    this.locationTitle,
    this.icon,
  });
  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Looking for your location...',
              style: theme.textTheme.caption,
            ),
            Padding(
              padding: EdgeInsetsDirectional.only(end: 13, top: 24, bottom: 24),
              child: icon ??
                  Icon(
                    FontAwesomeIcons.mapMarked,
                    size: 106,
                  ),
            ),
            Text(
              locationTitle ?? '396 NY-52, Woodbourne, NY 12788',
              style: theme.textTheme.subtitle1,
            ),
          ],
        ),
      ),
    );
  }
}
